import {Component, OnInit} from '@angular/core';
import {IrisService} from "./iris.service";
import {
    SVCParameters,
    SVCResult
} from "./types";

@Component({
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

    public svcParameters: SVCParameters = new SVCParameters();
    public svcResult: SVCResult;
    public iris: Iris = new Iris();
    public probabilityPredictions: ProbabilityPrediction[];
    
    constructor(private irisService: IrisService) {
    }

    ngOnInit() {
    }

    public trainModel() {
this.irisService.trainModel(this.svcParameters).subscribe((svcResult) => {
            this.svcResult = svcResult;
        });
    }
    public predictIris() {
	this.irisService.predictIris(this.iris).subscribe((probabilityPredictions) => {
        this.probabilityPredictions = probabilityPredictions;
    });
}
}
