from forms import LoginForm
from flask import Flask, render_template, request
from main import compute
import urllib.request 

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
	form = LoginForm(request.form)
	if request.method == 'POST' and form.validate():
		result = compute(form.Sepal_Length.data, form.Sepal_Width.data,
form.Petal_Length.data, form.Petal_Width.data)
	else:
		result = None	
	contents = urllib.request.urlopen("http://127.0.0.1:5000").read()
	return render_template('login.html',form=form, result=result)

if __name__ == '__main__':
    app.run(debug=True)


