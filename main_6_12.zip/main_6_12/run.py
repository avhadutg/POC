from forms import LoginForm
from flask import *
from main import compute
import sys


app = Flask(__name__)

app.config['SECRET_KEY'] = 'db77068e8c1b0060f6b0fe1fdcb47326'
@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def index():
	form = LoginForm()
	return render_template('login.html', title='Login', form=form) 
	
	result = 			compute(sepal_len=form.sepal_len.data,sepal_wid=form.sepal_wid.data,
petal_len=form.petal_len.data,petal_wid=form.petal_wid.data)
	print(result)	
	
	
		
	
if __name__ == '__main__':
    app.run(debug=True)
