from wtforms import Form, FloatField, validators
from flask_wtf import FlaskForm

class LoginForm(FlaskForm):

	sepal_len = FloatField('Sepal Length', validators=[validators.InputRequired()])
	sepal_wid = FloatField('Sepal Width', validators=[validators.InputRequired()])	
	petal_len = FloatField('Petal Length', validators=[validators.InputRequired()] )
	petal_wid = FloatField('Petal Width', validators=[validators.InputRequired()] )
   
	
