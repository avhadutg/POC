from wtforms import FloatField, SubmitField
from wtforms.validators import DataRequired, ValidationError
#from models import User
from flask_wtf import FlaskForm



class LoginForm(FlaskForm):

	sepal_len = FloatField('Sepal Length')
	sepal_wid = FloatField('Sepal Width')	
	petal_len = FloatField('Petal Length')
	petal_wid = FloatField('Petal Width')
   
	submit = SubmitField('Submit')
	
